// OWL CARDS
$(".cardss").owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    responsive: {
      100: {
        items: 1,
      },
    },
  });
  $(".owl-prev").html('<i class="bi bi-arrow-left-square-fill icon"></i>');
  $(".owl-next").html('<i class="bi bi-arrow-right-square-fill icon"></i>');

//   Products

